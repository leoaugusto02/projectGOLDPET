package vo;

public class Respostas {
	
	private String resposta;
	
	public Respostas() {
		super();
	}
	
	public Respostas(String resposta) {
		super();
		this.resposta = resposta;
	}
	
	public String getResposta() {
		return resposta;
	}
	
	public void setResposta(String respostas) {
		this.resposta = respostas;
	}
	
}
